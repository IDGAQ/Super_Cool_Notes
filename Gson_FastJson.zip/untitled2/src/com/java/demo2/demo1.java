package com.java.demo2;
import java.util.*;
import com.google.gson.Gson;

/**
 * @Author: Wanli
 * @Description: Gson demo
 * @Date Created in 2021--04--23 3:31 PM
 * @Modifed BY:
 */
public class demo1 {
    public static void main(String[] args) {
        //initiate
        Gson g = new Gson();
        Book b = new Book("100", "Apple", "Yum");

        // Java Object -> Json (toJson)
        String s = g.toJson(b);
        System.out.println(s);

        // print JSON {"id":"100","name":"Apple","info":"Yum"}
        System.out.println("\n");

        // Json -> Java Object (fromJson)
        g.fromJson("{\"id\":\"100\",\"name\":\"Apple\",\"info\":\"Yum\"}", Book.class);
        System.out.println(b.getId());

        HashMap data = g.fromJson("{\"id\":\"100\",\"name\":\"Apple\",\"info\":\"Yum\"}",HashMap.class);
        System.out.println(data.get("id").getClass());
    }
}