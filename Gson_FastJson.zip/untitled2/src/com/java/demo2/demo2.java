package com.java.demo2;
import com.alibaba.fastjson.JSON;
/**
 * @Author: Wanli
 * @Description: FastJson demo
 * @Date Created in 2021--04--23 4:35 PM
 * @Modifed BY:
 */
public class demo2 {
    public static void main(String[] args) {
        //{"id":"1002","info":"一二三，四五六","name":"唐诗三百首"}
        Book book = new Book("1002","唐诗三百首","一二三，四五六");

        // Java Object -> Json (toJSONString)
        String json = JSON.toJSONString(book);

        System.out.println(json);

        // // Json -> Java Object (parseObject)
        Book book2 = JSON.parseObject("{\"id\":\"1002\",\"info\":\"一二三，四五六\",\"name\":\"唐诗三百首\"}",Book.class);
        System.out.println(book2.getId());
    }
}
