import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

// 用Fixed ThreadPool Runs register() and login()
public class Server {
    public static void main(String[] args) {
        int choice = 0;


        // the System that stores <Username, Password>
        HashMap<String, String> theSystem = new HashMap<>();
        theSystem.put("admin", "123");
        theSystem.put("user", "abc");

        // Deserialize from theSystem.txt
        Deserialize(theSystem, "/Users/lukelu/IdeaProjects/Server+Client(2.0)/src/theSystem.txt");

        //CacheThreadPool
        ExecutorService service = Executors.newFixedThreadPool(4);


        //Thread 1
        try {
            ServerSocket server1 = new ServerSocket(7777);
            ServerSocket server2 = new ServerSocket(8888);

            for (int i = 0; i < 10; ++i) {
                // thread 1
                service.execute(new Runnable() {
                    @Override
                    public void run() {
                        register(theSystem, server1);
                    }
                });

                // thread 2
                service.execute(new Runnable() {
                    @Override
                    public void run() {
                        login(theSystem, server2);
                    }
                });
            }


        } catch (Exception e) {
            System.out.println("Register Port unable to Create");
        }


    }


    static void register(HashMap<String, String> theSystem, ServerSocket server) {
        try {
            //ServerSocket server = new ServerSocket(7777);

            System.out.println("Register Server is Ready, Waiting for User...");

            // Means User is Connected
            Socket socket = server.accept();
            System.out.println("Register Port is Connected! " + socket.getInetAddress().toString());

            // Listen1! get username
            InputStream is = socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String username = br.readLine();
            // Listen2! get password
            String password = br.readLine();
            System.out.println("Server Recieved: " + username + " " + password);

            OutputStream os = socket.getOutputStream();
            PrintStream ps = new PrintStream(os);

            if (theSystem.containsKey(username)) {
                // talk 1! username exist!
                ps.println("Username Exist Already!");
            } else {
                theSystem.put(username, password);
                //Serialize HashMap theSystem to theSystem.txt
                Serialize(theSystem, "/Users/lukelu/IdeaProjects/Server+Client(2.0)/src/theSystem.txt");
                // talk 1! password exist!
                ps.println("Registered Successful!");
            }


        } catch (Exception e) {
            System.out.println("Error Detected");
        }
    }


    static void login(HashMap<String, String> theSystem, ServerSocket server) {
        try {
            //ServerSocket server = new ServerSocket(8888);
            System.out.println("Login Server is Ready, Waiting for User...");

            // Means User is Connected
            Socket socket = server.accept();
            System.out.println("Login Port is Connected! " + socket.getInetAddress().toString());

            // Talk! (1)
            OutputStream os = socket.getOutputStream();
            PrintStream ps = new PrintStream(os);
            ps.println("Welcome!");

            // Listen! (2)
            InputStream is = socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String text = br.readLine();
            System.out.println("Server Recieved: " + text);

            // 1: admin, 2: user
            int type = 0;

            String thePassword;

            // Talk! (2)
            ps.println("Enter Username, ");

            // while loop ( get name and store password)
            while (true) {
                // small read 1
                String username = br.readLine();
                System.out.print("Username Recieved: " + username + "\n");
                if (theSystem.containsKey(username)) {
                    thePassword = theSystem.get(username);
                    // small talk 1
                    ps.println("Username Found");
                    break;
                } else {
                    // small talk 1
                    ps.println("Username Not Found, Please Try Again");
                }
            }

            // small talk 2
            ps.println("Enter Password, ");

            // small read 2
            String password = br.readLine();
            System.out.print("Password Recieved: " + password + "\n");
            if (password.equals(thePassword)) {
                // small talk 3
                ps.println("Logged In Successful!");
            } else {
                // small talk 3
                ps.println("Wrong Password");
            }


            System.out.println("Server is Disconnected");
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Error Detected");
        }

    }

    static void Serialize(HashMap<String, String> map, String filename) {
        // Serialize
        try {
            MySerializeUtil.mySerialize(map, filename);
            System.out.println("Serialized Succsessful");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void Deserialize(HashMap<String, String> map, String filename) {
        // Deserialize
        try {
            Object obj = MySerializeUtil.myDeserialize(filename);
            if (obj instanceof HashMap) {
                map = (HashMap<String, String>) obj;
                System.out.println("Deserialized Succsessful\n");
                System.out.println("theSystem:");
                for (Map.Entry<String, String> StringmyExpressEntry : map.entrySet()) {
                    System.out.print("Username: " + StringmyExpressEntry.getKey() + " ");
                    System.out.print("Password: " + StringmyExpressEntry.getValue() + " ");
                    System.out.println("\n");
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e2) {
            e2.printStackTrace();
        }

    }
}
