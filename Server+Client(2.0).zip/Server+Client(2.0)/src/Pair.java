public class Pair {
    String name;
    String password;

    Pair(String a, String b){
        name = a;
        password = b;
    }

    Pair(){
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}
